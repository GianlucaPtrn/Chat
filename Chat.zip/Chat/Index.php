<?php

require_once 'connexion.php';

$query = $dbh->query('SELECT * from users');

if (!$query) 
{
    var_dump($dbh->errorInfo());
    die('Error SQL');
}

var_dump($query);

$Users=$query->fetchAll(PDO::FETCH_CLASS);

var_dump($Users);
