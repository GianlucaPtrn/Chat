<?php

$user = 'root';

$pass ='root';

$server = 'mysql:host=localhost;dbname=chat';

$dbh = new PDO($server, $user, $pass);

var_dump($dbh);